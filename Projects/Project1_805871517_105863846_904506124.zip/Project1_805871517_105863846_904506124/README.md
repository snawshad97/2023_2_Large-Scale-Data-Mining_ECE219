Project 1
The code is put into seperate jupyter notebooks for Q1-Q4, Q5-Q9, and Q10-Q13 and each can be run seperately.